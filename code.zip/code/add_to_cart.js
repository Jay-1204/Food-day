function buy(){
  alert("Order Placed !!!");
}

  var iname_1 =localStorage.getItem("iname-1");
  var iname_2 =localStorage.getItem("iname-2");
  var iname_3 =localStorage.getItem("iname-3");
  var iname_4 =localStorage.getItem("iname-4");
  var iname_5 =localStorage.getItem("iname-5");
  var iname_6 =localStorage.getItem("iname-6");
  var iname_7 =localStorage.getItem("iname-7");
  var iname_8 =localStorage.getItem("iname-8");
  var iname_9 =localStorage.getItem("iname-9");
  var iname_10 =localStorage.getItem("iname-10");
  var iname_11 =localStorage.getItem("iname-11");
  var iname_12 =localStorage.getItem("iname-12");
  var iname_13 =localStorage.getItem("iname-13");
  var iname_14 =localStorage.getItem("iname-14");
  var iname_15 =localStorage.getItem("iname-15");
  var iname_16 =localStorage.getItem("iname-16");
  var iname_17 =localStorage.getItem("iname-17");
  var iname_18 =localStorage.getItem("iname-18");
  var iname_19 =localStorage.getItem("iname-19");
  var iname_20 =localStorage.getItem("iname-20");
  var iname_21 =localStorage.getItem("iname-21");
  var iname_22 =localStorage.getItem("iname-22");
  var iname_23 =localStorage.getItem("iname-23");
  var iname_24 =localStorage.getItem("iname-24");
  var iname_25 =localStorage.getItem("iname-25");
  var iname_26 =localStorage.getItem("iname-26");
  var iname_27 =localStorage.getItem("iname-27");
  var iname_28 =localStorage.getItem("iname-28");
  var iname_29 =localStorage.getItem("iname-29");
  var iname_30 =localStorage.getItem("iname-30");
  var iname_31 =localStorage.getItem("iname-31");
  var iname_32 =localStorage.getItem("iname-32");
  var iname_33 =localStorage.getItem("iname-33");
  var iprice_1 =localStorage.getItem("iprice-1");
  var iprice_2 =localStorage.getItem("iprice-2");
  var iprice_3 =localStorage.getItem("iprice-3");
  var iprice_4 =localStorage.getItem("iprice-4");
  var iprice_5 =localStorage.getItem("iprice-5");
  var iprice_6 =localStorage.getItem("iprice-6");
  var iprice_7 =localStorage.getItem("iprice-7");
  var iprice_8 =localStorage.getItem("iprice-8");
  var iprice_9 =localStorage.getItem("iprice-9");
  var iprice_10 =localStorage.getItem("iprice-10");
  var iprice_11 =localStorage.getItem("iprice-11");
  var iprice_12 =localStorage.getItem("iprice-12");
  var iprice_13 =localStorage.getItem("iprice-13");
  var iprice_14 =localStorage.getItem("iprice-14");
  var iprice_15 =localStorage.getItem("iprice-15");
  var iprice_16 =localStorage.getItem("iprice-16");
  var iprice_17 =localStorage.getItem("iprice-17");
  var iprice_18 =localStorage.getItem("iprice-18");
  var iprice_19 =localStorage.getItem("iprice-19");
  var iprice_20 =localStorage.getItem("iprice-20");
  var iprice_21 =localStorage.getItem("iprice-21");
  var iprice_22 =localStorage.getItem("iprice-22");
  var iprice_23 =localStorage.getItem("iprice-23");
  var iprice_24 =localStorage.getItem("iprice-24");
  var iprice_25 =localStorage.getItem("iprice-25");
  var iprice_26 =localStorage.getItem("iprice-26");
  var iprice_27 =localStorage.getItem("iprice-27");
  var iprice_28 =localStorage.getItem("iprice-28");
  var iprice_29 =localStorage.getItem("iprice-29");
  var iprice_30 =localStorage.getItem("iprice-30");
  var iprice_31 =localStorage.getItem("iprice-31");
  var iprice_32 =localStorage.getItem("iprice-32");
  var iprice_33 =localStorage.getItem("iprice-33");
  var qnt1 =localStorage.getItem("qnt1");
  var qnt2 =localStorage.getItem("qnt2");
  var qnt3 =localStorage.getItem("qnt3");
  var qnt4 =localStorage.getItem("qnt4");
  var qnt5 =localStorage.getItem("qnt5");
  var qnt6 =localStorage.getItem("qnt6");
  var qnt7 =localStorage.getItem("qnt7");
  var qnt8 =localStorage.getItem("qnt8");
  var qnt9 =localStorage.getItem("qnt9");
  var qnt10 =localStorage.getItem("qnt10");
  var qnt11 =localStorage.getItem("qnt11");
  var qnt12 =localStorage.getItem("qnt12");
  var qnt13 =localStorage.getItem("qnt13");
  var qnt14 =localStorage.getItem("qnt14");
  var qnt15 =localStorage.getItem("qnt15");
  var qnt16 =localStorage.getItem("qnt16");
  var qnt17 =localStorage.getItem("qnt17");
  var qnt18 =localStorage.getItem("qnt18");
  var qnt19 =localStorage.getItem("qnt19");
  var qnt20 =localStorage.getItem("qnt20");
  var qnt21 =localStorage.getItem("qnt21");
  var qnt22 =localStorage.getItem("qnt22");
  var qnt23 =localStorage.getItem("qnt23");
  var qnt24 =localStorage.getItem("qnt24");
  var qnt25 =localStorage.getItem("qnt25");
  var qnt26 =localStorage.getItem("qnt26");
  var qnt27 =localStorage.getItem("qnt27");
  var qnt28 =localStorage.getItem("qnt28");
  var qnt29 =localStorage.getItem("qnt29");
  var qnt30 =localStorage.getItem("qnt30");
  var qnt31 =localStorage.getItem("qnt31");
  var qnt32 =localStorage.getItem("qnt32");
  var qnt33 =localStorage.getItem("qnt33");

  if(qnt1 == null){
    qnt1 = 0
  }
  if(qnt2 == null){
    qnt2 = 0
  }
  if(qnt3 == null){
    qnt3 = 0
  }
  if(qnt4 == null){
    qnt4 = 0
  }
  if(qnt5 == null){
    qnt5 = 0
  }
  if(qnt6 == null){
    qnt6 = 0
  }
  if(qnt7 == null){
    qnt7 = 0
  }
  if(qnt8 == null){
    qnt8 = 0
  }
  if(qnt9 == null){
    qnt9 = 0
  }
  if(qnt10 == null){
    qnt10 = 0
  }
  if(qnt11 == null){
    qnt11 = 0
  }
  if(qnt12 == null){
    qnt12 = 0
  }
  if(qnt13 == null){
    qnt13 = 0
  }
  if(qnt14 == null){
    qnt14 = 0
  }
  if(qnt15 == null){
    qnt15 = 0
  }
  if(qnt16 == null){
    qnt16 = 0
  }
  if(qnt17 == null){
    qnt17 = 0
  }
  if(qnt18 == null){
    qnt18 = 0
  }
  if(qnt19 == null){
    qnt19 = 0
  }
  if(qnt20 == null){
    qnt20 = 0
  }
  if(qnt21 == null){
    qnt21 = 0
  }
  if(qnt22 == null){
    qnt22 = 0
  }
  if(qnt23 == null){
    qnt23 = 0
  }
  if(qnt24 == null){
    qnt24 = 0
  }
  if(qnt25 == null){
    qnt25 = 0
  }
  if(qnt26 == null){
    qnt26 = 0
  }
  if(qnt27 == null){
    qnt27 = 0
  }
  if(qnt28 == null){
    qnt28 = 0
  }
  if(qnt29 == null){
    qnt29 = 0
  }
  if(qnt30 == null){
    qnt30 = 0
  }
  if(qnt31 == null){
    qnt31 = 0
  }
  if(qnt32 == null){
    qnt32 = 0
  }
  if(qnt33 == null){
    qnt33 = 0
  }

  var price1 = localStorage.getItem("price1");
  var price2 = localStorage.getItem("price2");
  var price3 = localStorage.getItem("price3");
  var price4 = localStorage.getItem("price4");
  var price5 = localStorage.getItem("price5");
  var price6 = localStorage.getItem("price6");
  var price7 = localStorage.getItem("price7");
  var price8 = localStorage.getItem("price8");
  var price9 = localStorage.getItem("price9");
  var price10 = localStorage.getItem("price10");
  var price11 = localStorage.getItem("price11");
  var price12 = localStorage.getItem("price12");
  var price13 = localStorage.getItem("price13");
  var price14 = localStorage.getItem("price14");
  var price15 = localStorage.getItem("price15");
  var price16 = localStorage.getItem("price16");
  var price17 = localStorage.getItem("price17");
  var price18 = localStorage.getItem("price18");
  var price19 = localStorage.getItem("price19");
  var price20 = localStorage.getItem("price20");
  var price21 = localStorage.getItem("price21");
  var price22 = localStorage.getItem("price22");
  var price23 = localStorage.getItem("price23");
  var price24 = localStorage.getItem("price24");
  var price25 = localStorage.getItem("price25");
  var price26 = localStorage.getItem("price26");
  var price27 = localStorage.getItem("price27");
  var price28 = localStorage.getItem("price28");
  var price29 = localStorage.getItem("price29");
  var price30 = localStorage.getItem("price30");
  var price31 = localStorage.getItem("price31");
  var price32 = localStorage.getItem("price32");
  var price33 = localStorage.getItem("price33");
 
  if(price1 == null){
    price1 = 0
  }
  if(price2 == null){
    price2 = 0
  }
  if(price3 == null){
    price3 = 0
  }
  if(price4 == null){
    price4 = 0
  }
  if(price5 == null){
    price5 = 0
  }
  if(price6 == null){
    price6 = 0
  }
  if(price7 == null){
    price7 = 0
  }
  if(price8 == null){
    price8 = 0
  }
  if(price9 == null){
    price9 = 0
  }
  if(price10 == null){
    price10 = 0
  }
  if(price11 == null){
    price11 = 0
  }
  if(price12 == null){
    price12 = 0
  }
  if(price13 == null){
    price13 = 0
  }
  if(price14 == null){
    price14 = 0
  }
  if(price15 == null){
    price15 = 0
  }
  if(price16 == null){
    price16 = 0
  }
  if(price17 == null){
    price17 = 0
  }
  if(price18 == null){
    price18 = 0
  }
  if(price19 == null){
    price19 = 0
  }
  if(price20 == null){
    price20 = 0
  }
  if(price21 == null){
    price21 = 0
  }
  if(price22 == null){
    price22 = 0
  }
  if(price23 == null){
    price23 = 0
  }
  if(price24 == null){
    price24 = 0
  }
  if(price25 == null){
    price25 = 0
  }
  if(price26 == null){
    price26 = 0
  }
  if(price27 == null){
    price27 = 0
  }
  if(price28 == null){
    price28 = 0
  }
  if(price29 == null){
   price29 = 0
  }
  if(price30 == null){
    price30 = 0
  }
  if(price31 == null){
    price31 = 0
  }
  if(price32 == null){
    price32 = 0
  }
  if(price33 == null){
    price33 = 0
  }
  
  document.getElementById("price").innerHTML = parseInt(qnt1)*parseInt(price1) + parseInt(qnt2)*parseInt(price2)+ parseInt(qnt3)*parseInt(price3) + parseInt(qnt4)*parseInt(price4) + parseInt(qnt5)*parseInt(price5) + parseInt(qnt6)*parseInt(price6) + parseInt(qnt7)*parseInt(price7) + parseInt(qnt8)*parseInt(price8) + parseInt(qnt9)*parseInt(price9) + parseInt(qnt10)*parseInt(price10) + parseInt(qnt11)*parseInt(price11) + parseInt(qnt12)*parseInt(price12) + parseInt(qnt13)*parseInt(price13)+ parseInt(qnt14)*parseInt(price14)  + parseInt(qnt15)*parseInt(price15) + parseInt(qnt16)*parseInt(price16) +parseInt(qnt17)*parseInt(price17) + parseInt(qnt18)*parseInt(price18) + parseInt(qnt19)*parseInt(price19) + parseInt(qnt20)*parseInt(price20) + parseInt(qnt21)*parseInt(price21) + parseInt(qnt22)*parseInt(price22)  + parseInt(qnt23)*parseInt(price23) + parseInt(qnt24)*parseInt(price24) + parseInt(qnt25)*parseInt(price25) + parseInt(qnt26)*parseInt(price26) + parseInt(qnt27)*parseInt(price27) + parseInt(qnt28)*parseInt(price28) + parseInt(qnt29)*parseInt(price29) + parseInt(qnt30)*parseInt(price30) + parseInt(qnt31)*parseInt(price31) + parseInt(qnt32)*parseInt(price32) + parseInt(qnt33)*parseInt(price33);
  

  document.getElementById("t_items").innerText = parseInt(qnt1) + parseInt(qnt2) + parseInt(qnt3) + parseInt(qnt4) + parseInt(qnt5) + parseInt(qnt6) + parseInt(qnt7) + parseInt(qnt8) + parseInt(qnt9) + parseInt(qnt10) + parseInt(qnt11) + parseInt(qnt12) + parseInt(qnt13) + parseInt(qnt14) + parseInt(qnt15) + parseInt(qnt16) +parseInt(qnt17) + parseInt(qnt18) + parseInt(qnt19) + parseInt(qnt20) + parseInt(qnt21) + parseInt(qnt22) + parseInt(qnt23) + parseInt(qnt24) + parseInt(qnt25) + parseInt(qnt26) + parseInt(qnt27) + parseInt(qnt28) + parseInt(qnt29) + parseInt(qnt30) + parseInt(qnt31) + parseInt(qnt32) + parseInt(qnt33);
  //================================= ice-cream =========================
  if(iname_28 != undefined){
    items28 = document.getElementById("items28").innerHTML =" ";
    items28 = document.getElementById("items28").innerHTML = items28 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_28+'</p></div>';
    items28 = document.getElementById("items28").innerHTML = items28 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_28+'</p></div>';
    items28 = document.getElementById("items28").innerHTML = items28 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt28+'</p></div>';
    items28 = document.getElementById("items-div-28").style.border="1px solid black";
    items28 = document.getElementById("items28").style.padding="30px";
    items28 = document.getElementById("rmv28").style.display  ="block";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";

    function remove28(){
      localStorage.removeItem("iname-28");
      localStorage.removeItem("iprice-28");
      location.reload("add to cart.html");
      items28 = document.getElementById("items-div-28").style.border="none";
      localStorage.setItem("qnt28",0);
    }
  }
  if(iname_29 != undefined){
    items29 = document.getElementById("items29").innerHTML =" ";
    items29 = document.getElementById("items29").innerHTML = items29 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_29+'</p></div>';
    items29 = document.getElementById("items29").innerHTML = items29 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_29+'</p></div>';
    items29 = document.getElementById("items29").innerHTML = items29 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt29+'</p></div>';
    items29 = document.getElementById("items-div-29").style.border="1px solid black";
    items29 = document.getElementById("items29").style.padding="30px";
    items29 = document.getElementById("rmv29").style.display  ="block";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    function remove29(){
      localStorage.removeItem("iname-29");
      localStorage.removeItem("iprice-29");
      location.reload("add to cart.html");
      items29 = document.getElementById("items-div-29").style.border="none";
      localStorage.setItem("qnt29",0);
      
    }
  }
  if(iname_30 != undefined){
    items30 = document.getElementById("items30").innerHTML =" ";
    items30 = document.getElementById("items30").innerHTML = items30 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_30+'</p></div>';
    items30 = document.getElementById("items30").innerHTML = items30 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_30+'</p></div>';
    items30 = document.getElementById("items30").innerHTML = items30 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt30+'</p></div>';
    items30 = document.getElementById("items-div-30").style.border="1px solid black";
    items30 = document.getElementById("items30").style.padding="30px";
    items30 = document.getElementById("rmv30").style.display  ="block";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    function remove30(){
      localStorage.removeItem("iname-30");
      localStorage.removeItem("iprice-30");
      location.reload("add to cart.html");
      items30 = document.getElementById("items-div-30").style.border="none";
      localStorage.setItem("qnt30",0);
    }
  }
  if(iname_31 != undefined){
    items31 = document.getElementById("items31").innerHTML =" ";
    items31 = document.getElementById("items31").innerHTML = items31 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_31+'</p></div>';
    items31 = document.getElementById("items31").innerHTML = items31 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_31+'</p></div>';
    items31 = document.getElementById("items31").innerHTML = items31 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt31+'</p></div>';
    items31 = document.getElementById("items-div-31").style.border="1px solid black";
    items31 = document.getElementById("items31").style.padding="30px";
    items31 = document.getElementById("rmv31").style.display  ="block";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    function remove31(){
      localStorage.removeItem("iname-31");
      localStorage.removeItem("iprice-31");
      location.reload("add to cart.html");
      items31 = document.getElementById("items-div-31").style.border="none";
      localStorage.setItem("qnt31",0);
    }
  }
  if(iname_32 != undefined){
    items32 = document.getElementById("items32").innerHTML =" ";
    items32 = document.getElementById("items32").innerHTML = items32 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_32+'</p></div>';
    items32 = document.getElementById("items32").innerHTML = items32 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_32+'</p></div>';
    items32 = document.getElementById("items32").innerHTML = items32 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt32+'</p></div>';
    items32 = document.getElementById("items-div-32").style.border="1px solid black";
    items32 = document.getElementById("items32").style.padding="30px";
    items32 = document.getElementById("rmv32").style.display  ="block";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    function remove32(){
      localStorage.removeItem("iname-32");
      localStorage.removeItem("iprice-32");
      location.reload("add to cart.html");
      items32 = document.getElementById("items-div-32").style.border="none";
      localStorage.setItem("qnt32",0);
    }
  }

  if(iname_33 != undefined){
    items33 = document.getElementById("items33").innerHTML =" ";
    items33 = document.getElementById("items33").innerHTML = items33 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_33+'</p></div>';
    items33 = document.getElementById("items33").innerHTML = items33 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_33+'</p></div>';
    items33 = document.getElementById("items33").innerHTML = items33 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt33+'</p></div>';
    items33 = document.getElementById("items-div-33").style.border="1px solid black";
    items33 = document.getElementById("items33").style.padding="30px";
    items33 = document.getElementById("rmv33").style.display  ="block";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    function remove33(){
      localStorage.removeItem("iname-33");
      localStorage.removeItem("iprice-33");
      location.reload("add to cart.html");
      items33 = document.getElementById("items-div-33").style.border="none";
      localStorage.setItem("qnt33",0);
    }
  }

  //======================= sub =============================
  if(iname_25 != undefined){
    items25 = document.getElementById("items25").innerHTML =" ";
    items25 = document.getElementById("items25").innerHTML = items25 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_25+'</p></div>';
    items25 = document.getElementById("items25").innerHTML = items25 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_25+'</p></div>';
    items25 = document.getElementById("items25").innerHTML = items25 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt25+'</p></div>';
    items25 = document.getElementById("items-div-25").style.border="1px solid black";
    items25 = document.getElementById("items25").style.padding="30px";
    items25 = document.getElementById("rmv25").style.display  ="block";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    function remove25(){
      localStorage.removeItem("iname-25");
      localStorage.removeItem("iprice-25");
      location.reload("add to cart.html");
      items25 = document.getElementById("items-div-25").style.border="none";
      localStorage.setItem("qnt25",0);
    }
  }
  if(iname_26 != undefined){
    items26 = document.getElementById("items26").innerHTML =" ";
    items26 = document.getElementById("items26").innerHTML = items26 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_26+'</p></div>';
    items26 = document.getElementById("items26").innerHTML = items26 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_26+'</p></div>';
    items26 = document.getElementById("items26").innerHTML = items26 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt26+'</p></div>';
    items26 = document.getElementById("items-div-26").style.border="1px solid black";
    items26 = document.getElementById("items26").style.padding="30px";
    items26 = document.getElementById("rmv26").style.display  ="block";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    function remove26(){
      localStorage.removeItem("iname-26");
      localStorage.removeItem("iprice-26");
      location.reload("add to cart.html");
      items26 = document.getElementById("items-div-26").style.border="none";
      localStorage.setItem("qnt26",0);
    }
  }

  if(iname_27 != undefined){
    items27 = document.getElementById("items27").innerHTML =" ";
    items27 = document.getElementById("items27").innerHTML = items27 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_27+'</p></div>';
    items27 = document.getElementById("items27").innerHTML = items27 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_27+'</p></div>';
    items27 = document.getElementById("items27").innerHTML = items27 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt27+'</p></div>';
    items27 = document.getElementById("items-div-27").style.border="1px solid black";
    items27 = document.getElementById("items27").style.padding="30px";
    items27 = document.getElementById("rmv27").style.display  ="block";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    function remove27(){
      localStorage.removeItem("iname-27");
      localStorage.removeItem("iprice-27");
      location.reload("add to cart.html");
      items27 = document.getElementById("items-div-27").style.border="none";
      localStorage.setItem("qnt27",0);
    }
  }

  //=========================sandwich ================
  if(iname_19 != undefined){
    items19 = document.getElementById("items19").innerHTML =" ";
    items19 = document.getElementById("items19").innerHTML = items19 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_19+'</p></div>';
    items19 = document.getElementById("items19").innerHTML = items19 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_19+'</p></div>';
    items19 = document.getElementById("items19").innerHTML = items19 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt19+'</p></div>';
    items19 = document.getElementById("items-div-19").style.border="1px solid black";
    items19 = document.getElementById("items19").style.padding="30px";
    items19 = document.getElementById("rmv19").style.display  ="block";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    function remove19(){
      localStorage.removeItem("iname-19");
      localStorage.removeItem("iprice-19");
      location.reload("add to cart.html");
      items19 = document.getElementById("items-div-19").style.border="none";
      localStorage.setItem("qnt19",0);
    }
  }
  if(iname_20 != undefined){
    items20 = document.getElementById("items20").innerHTML =" ";
    items20 = document.getElementById("items20").innerHTML = items20 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_20+'</p></div>';
    items20 = document.getElementById("items20").innerHTML = items20 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_20+'</p></div>';
    items20 = document.getElementById("items20").innerHTML = items20 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt20+'</p></div>';
    items20 = document.getElementById("items-div-20").style.border="1px solid black";
    items20 = document.getElementById("items20").style.padding="30px";
    items20 = document.getElementById("rmv20").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    function remove20(){
      localStorage.removeItem("iname-20");
      localStorage.removeItem("iprice-20");
      location.reload("add to cart.html");
      items20 = document.getElementById("items-div-20").style.border="none";
      localStorage.setItem("qnt20",0);
    }
  }
  if(iname_21 != undefined){
    items21 = document.getElementById("items21").innerHTML =" ";
    items21 = document.getElementById("items21").innerHTML = items21 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_21+'</p></div>';
    items21 = document.getElementById("items21").innerHTML = items21 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_21+'</p></div>';
    items21 = document.getElementById("items21").innerHTML = items21 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt21+'</p></div>';
    items21 = document.getElementById("items-div-21").style.border="1px solid black";
    items21 = document.getElementById("items21").style.padding="30px";
    items21 = document.getElementById("rmv21").style.display  ="block";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    function remove21(){
      localStorage.removeItem("iname-21");
      localStorage.removeItem("iprice-21");
      location.reload("add to cart.html");
      items21 = document.getElementById("items-div-21").style.border="none";
      localStorage.setItem("qnt21",0);
    }
  }  if(iname_22 != undefined){
    items22 = document.getElementById("items22").innerHTML =" ";
    items22 = document.getElementById("items22").innerHTML = items22 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_22+'</p></div>';
    items22 = document.getElementById("items22").innerHTML = items22 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_22+'</p></div>';
    items22 = document.getElementById("items22").innerHTML = items22 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt22+'</p></div>';
    items22 = document.getElementById("items-div-22").style.border="1px solid black";
    items22 = document.getElementById("items22").style.padding="30px";
    items22 = document.getElementById("rmv22").style.display  ="block";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    function remove22(){
      localStorage.removeItem("iname-22");
      localStorage.removeItem("iprice-22");
      location.reload("add to cart.html");
      items22 = document.getElementById("items-div-22").style.border="none";
      localStorage.setItem("qnt22",0);
    }
  }  if(iname_23 != undefined){
    items23 = document.getElementById("items23").innerHTML =" ";
    items23 = document.getElementById("items23").innerHTML = items23 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_23+'</p></div>';
    items23 = document.getElementById("items23").innerHTML = items23 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_23+'</p></div>';
    items23 = document.getElementById("items23").innerHTML = items23 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt23+'</p></div>';
    items23 = document.getElementById("items-div-23").style.border="1px solid black";
    items23 = document.getElementById("items23").style.padding="30px";
    items23 = document.getElementById("rmv23").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    function remove23(){
      localStorage.removeItem("iname-23");
      localStorage.removeItem("iprice-23");
      location.reload("add to cart.html");
      items23 = document.getElementById("items-div-23").style.border="none";
      localStorage.setItem("qnt23",0);
    }
  }  if(iname_24 != undefined){
    items24 = document.getElementById("items24").innerHTML =" ";
    items24 = document.getElementById("items24").innerHTML = items24 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_24+'</p></div>';
    items24 = document.getElementById("items24").innerHTML = items24 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_24+'</p></div>';
    items24 = document.getElementById("items24").innerHTML = items24 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt24+'</p></div>';
    items24 = document.getElementById("items-div-24").style.border="1px solid black";
    items24 = document.getElementById("items24").style.padding="30px";
    items24 = document.getElementById("rmv24").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    function remove24(){
      localStorage.removeItem("iname-24");
      localStorage.removeItem("iprice-24");
      location.reload("add to cart.html");
      items24 = document.getElementById("items-div-24").style.border="none";
      localStorage.setItem("qnt24",0);
    }
  }

  //=========================== pasta ============================
  if(iname_13 != undefined){
    items13 = document.getElementById("items13").innerHTML =" ";
    items13 = document.getElementById("items13").innerHTML = items13 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_13+'</p></div>';
    items13 = document.getElementById("items13").innerHTML = items13 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_13+'</p></div>';
    items13 = document.getElementById("items13").innerHTML = items13 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt13+'</p></div>';
    items13 = document.getElementById("items-div-13").style.border="1px solid black";
    items13 = document.getElementById("items13").style.padding="30px";
    items13 = document.getElementById("rmv13").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    function remove13(){
      localStorage.removeItem("iname-13");
      localStorage.removeItem("iprice-13");
      location.reload("add to cart.html");
      items13 = document.getElementById("items-div-13").style.border="none";
      localStorage.setItem("qnt13",0);
    }
  }
  if(iname_14 != undefined){
    items14 = document.getElementById("items14").innerHTML =" ";
    items14 = document.getElementById("items14").innerHTML = items14 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_14+'</p></div>';
    items14 = document.getElementById("items14").innerHTML = items14 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_14+'</p></div>';
    items14 = document.getElementById("items14").innerHTML = items14 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt14+'</p></div>';
    items14 = document.getElementById("items-div-14").style.border="1px solid black";
    items14 = document.getElementById("items14").style.padding="30px";
    items14 = document.getElementById("rmv14").style.display  ="block";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    function remove14(){
      localStorage.removeItem("iname-14");
      localStorage.removeItem("iprice-14");
      location.reload("add to cart.html");
      items14 = document.getElementById("items-div-14").style.border="none";
      localStorage.setItem("qnt14",0);
    }
  }
  if(iname_15 != undefined){
    items15 = document.getElementById("items15").innerHTML =" ";
    items15 = document.getElementById("items15").innerHTML = items15 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_15+'</p></div>';
    items15 = document.getElementById("items15").innerHTML = items15 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_15+'</p></div>';
    items15 = document.getElementById("items15").innerHTML = items15 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt15+'</p></div>';
    items15 = document.getElementById("items-div-15").style.border="1px solid black";
    items15 = document.getElementById("items15").style.padding="30px";
    items15 = document.getElementById("rmv15").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    function remove15(){
      localStorage.removeItem("iname-15");
      localStorage.removeItem("iprice-15");
      location.reload("add to cart.html");
      items15 = document.getElementById("items-div-15").style.border="none";
      localStorage.setItem("qnt15",0);
    }
  }
  if(iname_16 != undefined){
    items16 = document.getElementById("items16").innerHTML =" ";
    items16 = document.getElementById("items16").innerHTML = items16 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_16+'</p></div>';
    items16 = document.getElementById("items16").innerHTML = items16 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_16+'</p></div>';
    items16 = document.getElementById("items16").innerHTML = items16 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt16+'</p></div>';
    items16 = document.getElementById("items-div-16").style.border="1px solid black";
    items16 = document.getElementById("items16").style.padding="30px";
    items16 = document.getElementById("rmv16").style.display  ="block";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    function remove16(){
      localStorage.removeItem("iname-16");
      localStorage.removeItem("iprice-16");
      location.reload("add to cart.html");
      items16 = document.getElementById("items-div-16").style.border="none";
      localStorage.setItem("qnt16",0);
    }
  }

  if(iname_17 != undefined){
    items17 = document.getElementById("items17").innerHTML =" ";
    items17 = document.getElementById("items17").innerHTML = items17 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_17+'</p></div>';
    items17 = document.getElementById("items17").innerHTML = items17 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_17+'</p></div>';
    items17 = document.getElementById("items17").innerHTML = items17 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt17+'</p></div>';
    items17 = document.getElementById("items-div-17").style.border="1px solid black";
    items17 = document.getElementById("items17").style.padding="30px";
    items17 = document.getElementById("rmv17").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    function remove17(){
      localStorage.removeItem("iname-17");
      localStorage.removeItem("iprice-17");
      location.reload("add to cart.html");
      items17 = document.getElementById("items-div-17").style.border="none";
      localStorage.setItem("qnt17",0);
    }
  }

  if(iname_18 != undefined){
    items18 = document.getElementById("items18").innerHTML =" ";
    items18 = document.getElementById("items18").innerHTML = items18 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_18+'</p></div>';
    items18 = document.getElementById("items18").innerHTML = items18 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_18+'</p></div>';
    items18 = document.getElementById("items18").innerHTML = items18 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt18+'</p></div>';
    items18 = document.getElementById("items-div-18").style.border="1px solid black";
    items18 = document.getElementById("items18").style.padding="30px";
    items18 = document.getElementById("rmv18").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    function remove18(){
      localStorage.removeItem("iname-18");
      localStorage.removeItem("iprice-18");
      location.reload("add to cart.html");
      items18 = document.getElementById("items-div-18").style.border="none";
      localStorage.setItem("qnt18",0);
    }
  }

//========================== pizza ==============================
  if(iname_9 != undefined){
    items9 = document.getElementById("items9").innerHTML =" ";
    items9 = document.getElementById("items9").innerHTML = items9 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_9+'</p></div>';
    items9 = document.getElementById("items9").innerHTML = items9 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_9+'</p></div>';
    items9 = document.getElementById("items9").innerHTML = items9 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt9+'</p></div>';
    items9 = document.getElementById("items-div-9").style.border="1px solid black";
    items9 = document.getElementById("items9").style.padding="30px";
    items9 = document.getElementById("rmv9").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    function remove9(){
      localStorage.removeItem("iname-9");
      localStorage.removeItem("iprice-9");
      location.reload("add to cart.html");
      items9 = document.getElementById("items-div-9").style.border="none";
      localStorage.setItem("qnt9",0);
    }
  }
  
  if(iname_10 != undefined){
    items10 = document.getElementById("items10").innerHTML =" ";
    items10 = document.getElementById("items10").innerHTML = items10 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_10+'</p></div>';
    items10 = document.getElementById("items10").innerHTML = items10 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_10+'</p></div>';
    items10 = document.getElementById("items10").innerHTML = items10 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt10+'</p></div>';
    items10 = document.getElementById("items-div-10").style.border="1px solid black";
    items10 = document.getElementById("items10").style.padding="30px";
    items10 = document.getElementById("rmv10").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    function remove10(){
      localStorage.removeItem("iname-10");
      localStorage.removeItem("iprice-10");
      location.reload("add to cart.html");
      items10 = document.getElementById("items-div-10").style.border="none";
      localStorage.setItem("qnt10",0);
    }
  }
  if(iname_11 != undefined){
    items11 = document.getElementById("items11").innerHTML =" ";
    items11 = document.getElementById("items11").innerHTML = items11 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_11+'</p></div>';
    items11 = document.getElementById("items11").innerHTML = items11 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_11+'</p></div>';
    items11 = document.getElementById("items11").innerHTML = items11 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt11+'</p></div>';
    items11 = document.getElementById("items-div-11").style.border="1px solid black";
    items11 = document.getElementById("items11").style.padding="30px";
    items11 = document.getElementById("rmv11").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    function remove11(){
    localStorage.removeItem("iname-11");
      localStorage.removeItem("iprice-11");
      location.reload("add to cart.html");
      items11 = document.getElementById("items-div-11").style.border="none";
      localStorage.setItem("qnt11",0);
    }
  }
 if(iname_12 != undefined){
    items12 = document.getElementById("items12").innerHTML =" ";
    items12 = document.getElementById("items12").innerHTML = items12 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_12+'</p></div>';
    items12 = document.getElementById("items12").innerHTML = items12 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_12+'</p></div>';
    items12 = document.getElementById("items12").innerHTML = items12 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt12+'</p></div>';
    items12 = document.getElementById("items-div-12").style.border="1px solid black";
    items12 = document.getElementById("items12").style.padding="30px";
    items12 = document.getElementById("rmv12").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    function remove12(){
      localStorage.removeItem("iname-12");
      localStorage.removeItem("iprice-12");
      location.reload("add to cart.html");
      items12 = document.getElementById("items-div-12").style.border="none";
      localStorage.setItem("qnt12",0);
    }
  }


  if(iname_8 != undefined){
    items8 = document.getElementById("items8").innerHTML =" ";
    items8 = document.getElementById("items8").innerHTML = items8 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_8+'</p></div>';
    items8 = document.getElementById("items8").innerHTML = items8 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_8+'</p></div>';
    items8 = document.getElementById("items8").innerHTML = items8 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt8+'</p></div>';
    items8 = document.getElementById("items-div-8").style.border="1px solid black";
    items8 = document.getElementById("items8").style.padding="30px";
    items8 = document.getElementById("rmv8").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    function remove8(){
      localStorage.removeItem("iname-8");
      localStorage.removeItem("iprice-8");
      location.reload("add to cart.html");
      items8 = document.getElementById("items-div-8").style.border="none";
      localStorage.setItem("qnt8",0);
    }
  }
  if(iname_7 != undefined){
    items7 = document.getElementById("items7").innerHTML =" ";
    items7 = document.getElementById("items7").innerHTML = items7 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_7+'</p></div>';
    items7 = document.getElementById("items7").innerHTML = items7 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_7+'</p></div>';
    items7 = document.getElementById("items7").innerHTML = items7 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt7+'</p></div>';
    items7 = document.getElementById("items-div-7").style.border="1px solid black";
    items7 = document.getElementById("items7").style.padding="30px";
    items7 = document.getElementById("rmv7").style.display="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    function remove7(){
      localStorage.removeItem("iname-7");
      localStorage.removeItem("iprice-7");
      location.reload("add to cart.html");
      items7 = document.getElementById("items-div-7").style.border="none";
      localStorage.setItem("qnt7",0);
    }
  }

    // =============== burger ==========================
  if(iname_1 != undefined){
    items1 = document.getElementById("items1").innerHTML =" ";
    items1 = document.getElementById("items1").innerHTML = items1 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_1+'</p></div>';
    items1 = document.getElementById("items1").innerHTML = items1 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_1+'</p></div>';
    items1 = document.getElementById("items1").innerHTML = items1 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt1+'</p></div>';
    items1 = document.getElementById("rmv1").style.display="block";
    items1 = document.getElementById("items-div-1").style.border="1px solid black";
    items1 = document.getElementById("items1").style.padding="30px";
    document.getElementById("t_price").style.display  ="block";
    document.getElementById("disp").style.display  ="none";
    function remove1(){
      localStorage.removeItem("iname-1");
      localStorage.removeItem("iprice-1");
      location.reload("add to cart.html");
      items1 = document.getElementById("items-div-1").style.border="none";
      localStorage.setItem("qnt1",0);
    }
  }
  if(iname_2 != undefined){
    items2 = document.getElementById("items2").innerHTML =" ";
    items2 = document.getElementById("items2").innerHTML = items2 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_2+'</p></div>';
    items2 = document.getElementById("items2").innerHTML = items2 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_2+'</p></div>';
    items2 = document.getElementById("items2").innerHTML = items2 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt2+'</p></div>';
    items2 = document.getElementById("rmv2").style.display="block";
    items2 = document.getElementById("items-div-2").style.border="1px solid black";
    items2 = document.getElementById("items2").style.padding="30px";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    
    function remove2(){
      localStorage.removeItem("iname-2");
      localStorage.removeItem("iprice-2");
      items2 = document.getElementById("rmv2").style.display="block";
      location.reload("add to cart.html");
      localStorage.setItem("qnt2",0);
      items1 = document.getElementById("items-div-2").style.border="none";
    }
  }
  if(iname_3 != undefined){
    items3 = document.getElementById("items3").innerHTML =" ";
    items3 = document.getElementById("items3").innerHTML = items3 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_3+'</p></div>';
    items3 = document.getElementById("items3").innerHTML = items3 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_3+'</p></div>';
    items3 = document.getElementById("items3").innerHTML = items3 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt3+'</p></div>';
    items3 = document.getElementById("rmv3").style.display="block";
    items3 = document.getElementById("items-div-3").style.border="1px solid black";
    items3 = document.getElementById("items3").style.padding="30px";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    
    function remove3(){
      localStorage.removeItem("iname-3");
      localStorage.removeItem("iprice-3");
      location.reload("add to cart.html");
      items3 = document.getElementById("items-div-3").style.border="none";
      localStorage.setItem("qnt3",0);
    }
  }
  if(iname_4 != undefined){
    items4 = document.getElementById("items4").innerHTML =" ";
    items4 = document.getElementById("items4").innerHTML = items4 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_4+'</p></div>';
    items4 = document.getElementById("items4").innerHTML = items4 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_4+'</p></div>';
    items4 = document.getElementById("items4").innerHTML = items4 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt4+'</p></div>';
    items4 = document.getElementById("rmv4").style.display="block";
    items4 = document.getElementById("items-div-4").style.border="1px solid black";
    items4 = document.getElementById("items4").style.padding="30px";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";
    
    function remove4(){
      localStorage.removeItem("iname-4");
      localStorage.removeItem("iprice-4");
      location.reload("add to cart.html");
      items4 = document.getElementById("items-div-4").style.border="none";
      localStorage.setItem("qnt4",0);
    }
  }
  if(iname_5 != undefined){
    items5 = document.getElementById("items5").innerHTML =" ";
    items5 = document.getElementById("items5").innerHTML = items5 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_5+'</p></div>';
    items5 = document.getElementById("items5").innerHTML = items5 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_5+'</p></div>';
    items5 = document.getElementById("items5").innerHTML = items5 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt5+'</p></div>';
    items5 = document.getElementById("items-div-5").style.border="1px solid black";
    items5 = document.getElementById("items5").style.padding="30px";
    items5 = document.getElementById("rmv5").style.display="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";

    function remove5(){
      localStorage.removeItem("iname-5");
      localStorage.removeItem("iprice-5");
      items5 = document.getElementById("items-div-5").style.border="none";
      location.reload("add to cart.html");
      localStorage.setItem("qnt5",0);
    }
  }
  
  if(iname_6 != undefined){
    items6 = document.getElementById("items6").innerHTML =" ";
    items6 = document.getElementById("items6").innerHTML = items6 + '<div class="items"><p class="label"> Item Name:<p><p class="item_name">'+iname_6+'</p></div>';
    items6 = document.getElementById("items6").innerHTML = items6 + '<div class="items"><p class="label"> Item Price:<p><p class="item_name">'+iprice_6+'</p></div>';
    items6 = document.getElementById("items6").innerHTML = items6 + '<div class="items"><p class="label"> Quantity:<p><p class="item_name">'+qnt6+'</p></div>';
    items6 = document.getElementById("items-div-6").style.border="1px solid black";
    items6 = document.getElementById("items6").style.padding="30px";
    items6 = document.getElementById("rmv6").style.display="block";
    document.getElementById("disp").style.display  ="none";
    document.getElementById("t_price").style.display  ="block";

    function remove6(){
      localStorage.removeItem("iname-6");
      localStorage.removeItem("iprice-6");
      location.reload("add to cart.html");
      items6 = document.getElementById("items-div-6").style.border="none";
      localStorage.setItem("qnt6",0);
    }
  }